package ar.edu.ort.tp1.pacial2.clases;

public enum TipoDeJuego {
	AVENTURA, RPG, PLATAFORMAS, CARRERAS;
}
