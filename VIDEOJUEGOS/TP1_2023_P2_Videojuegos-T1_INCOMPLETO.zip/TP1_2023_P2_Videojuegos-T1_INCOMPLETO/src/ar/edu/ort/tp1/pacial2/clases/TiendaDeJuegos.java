package ar.edu.ort.tp1.pacial2.clases;

import ar.edu.ort.tp1.tdas.implementaciones.ColaNodos;
import ar.edu.ort.tp1.tdas.interfaces.Cola;
import ar.edu.ort.tp1.tdas.interfaces.ListaOrdenada;

public class TiendaDeJuegos implements Mostrable {

	private static final String MSG_JUEGO_NULO = "No se pudo fabricar Juego o Cupon nulo.";
	private static final String MSG_TIPO_DE_JUEGO = "Error de parametros incorporando tipos de juegos";
	private static final String MSG_TOTALES = "La venta total fue: $%8.2f\n";
	public static final String MENSAJE_FABRICA_POR_TIPO = "Se han fabricado: %d RPG, %d Aventura, %d Plataformas y %d Carreras\n";
	private String nombre;

	// @TODO A completar


	public TiendaDeJuegos(String nombre) {
		setNombre(nombre);
		// @TODO A completar
	}

	private void setNombre(String nombre) {
		if (nombre == null || nombre.isEmpty()) {
			throw new IllegalArgumentException("Nombre de Juego Invalido");
		}
		this.nombre = nombre;
	}

	public void ingresarCuponesDeJuegos(TipoDeJuego tipoDeJuego, Cupon cupon, int cantidad) {
		// @TODO A completar
	}

	public void ingresarPedido(Juego juego, Cupon cupon) {
		// @TODO A completar
	}

	public int cantidadDeJuegosEntrePrecios(float precioMinimo, float precioMaximo) {
		// @TODO A completar
		return 0;
	}

	public boolean veritificarStockDeCupones(Cupon cupon, TipoDeJuego tipoDeJuego) {
		// @TODO A completar
		return false;
	}

	@Override
	public void mostrar() {
		// @TODO A completar
	}

}
